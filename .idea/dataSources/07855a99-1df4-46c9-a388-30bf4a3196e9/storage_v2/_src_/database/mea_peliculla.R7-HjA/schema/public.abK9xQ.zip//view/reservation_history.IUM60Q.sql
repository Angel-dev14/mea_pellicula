create view reservation_history(customer_id, full_name, title, start_date, cinema_room, cinema) as
SELECT DISTINCT c.person_id                                            AS customer_id,
                (p.first_name::text || ' '::text) || p.last_name::text AS full_name,
                m.title,
                ms.start_date,
                cr.name                                                AS cinema_room,
                c2.name                                                AS cinema
FROM persons p
         JOIN customers c ON p.id = c.person_id
         JOIN payments p2 ON c.person_id = p2.customer_id
         JOIN tickets t ON p2.reservation_id = t.reservation_id
         JOIN movie_screening_seats mss ON t.movie_screening_seat_id = mss.id
         JOIN movie_screenings ms ON mss.movie_screening_id = ms.id
         JOIN cinema_rooms cr ON ms.cinema_room_id = cr.id
         JOIN cinemas c2 ON cr.cinema_id = c2.id
         JOIN movies m ON ms.movie_id = m.id;

alter table reservation_history
    owner to postgres;

