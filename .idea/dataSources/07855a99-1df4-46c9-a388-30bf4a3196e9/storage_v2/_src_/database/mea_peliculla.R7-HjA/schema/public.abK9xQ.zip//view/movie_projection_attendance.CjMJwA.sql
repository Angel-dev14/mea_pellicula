create view movie_projection_attendance(movie_id, title, bought_seats, all_available_seats) as
SELECT m.id             AS movie_id,
       m.title,
       sum(
               CASE
                   WHEN mss.free IS FALSE THEN 1
                   ELSE 0
                   END) AS bought_seats,
       count(mss.id)    AS all_available_seats
FROM movie_screenings ms
         JOIN movie_screening_seats mss ON ms.id = mss.movie_screening_id
         JOIN movies m ON ms.movie_id = m.id
GROUP BY m.id, m.title;

alter table movie_projection_attendance
    owner to postgres;

