create view movies_by_genre(genre_id, genre, title) as
SELECT g.id   AS genre_id,
       g.name AS genre,
       m.title
FROM movie_screenings ms
         JOIN movies m ON ms.movie_id = m.id
         JOIN movie_genres mg ON m.id = mg.movie_id
         JOIN genres g ON mg.genre_id = g.id
WHERE ms.start_date >= now();

alter table movies_by_genre
    owner to postgres;

