create procedure add_actor_and_role(IN _actor_id bigint, IN _role_id bigint, IN _movie_id bigint, IN _role_name character varying)
    language plpgsql
as
$$
begin

    if ((_actor_id in (select person_Id from actors)) or
        ((select id from persons where id = _role_id) is null) or
        ((select id from movies where id = _movie_id) is null) or
        ((select id from roles where id = _role_id) is null)) then
        raise exception 'Adding not successful.
        Make sure the person you are trying to add is a registered person in the database and is not already an actor.
        Also, please make sure you are adding the actor to an existing movie and role';
    end if;

    insert into actors values (_actor_id);

    insert into actor_movies
    values ((select id from actor_movies order by id desc limit 1) + 1, _role_name, _actor_id, _movie_id);

    insert into actor_movie_roles
    values ((select count(*) from actor_movie_roles) + 1,
            (select id from actor_movies where movie_id = _movie_id and actor_id = _actor_id), _role_id);

end;
$$;

alter procedure add_actor_and_role(bigint, bigint, bigint, varchar) owner to postgres;

