create view list_projections_next_month(movie_id, title, city, cinema_name, cinema_room, start_date) as
SELECT DISTINCT m.id    AS movie_id,
                m.title,
                c2.name AS city,
                c.name  AS cinema_name,
                cr.name AS cinema_room,
                ms.start_date
FROM movie_screenings ms
         JOIN movies m ON ms.movie_id = m.id
         JOIN cinema_rooms cr ON ms.cinema_room_id = cr.id
         JOIN cinemas c ON cr.cinema_id = c.id
         JOIN cities c2 ON c.city_id = c2.id
WHERE ms.start_date <= (now() + '31 days'::interval)
  AND ms.start_date >= now();

alter table list_projections_next_month
    owner to postgres;

