create procedure create_tickets()
    language plpgsql
as
$$
declare
    number_of_tickets integer;
    reservation record;
    movie_screening_id bigint;
    query text;
    movie_screenings_seats bigint[];
    movie_screening_seat bigint;
    movie_price integer;
BEGIN
    for reservation in select * from reservations loop
        SELECT CAST(random() * 3 + 1 as integer) into number_of_tickets;
        select id, base_price from movie_screenings where is_finished = true order by random() limit 1 into movie_screening_id, movie_price;
        query := 'SELECT array_agg(id) FROM (SELECT id FROM movie_screening_seats WHERE movie_screening_id = ' || movie_screening_id || ' and free = true order by random() LIMIT ' || number_of_tickets || ') AS subquery';
        execute query into movie_screenings_seats;
        foreach movie_screening_seat in array movie_screenings_seats loop
            insert into tickets(date_created, paid_price, reservation_id, movie_screening_seat_id)
            values (reservation.date_created, movie_price, reservation.id, movie_screening_seat);
            update movie_screening_seats set free = false where id = movie_screening_seat;
            end loop;
        end loop;
end
$$;

alter procedure create_tickets() owner to postgres;

