create function create_movie_screening_seats() returns trigger
    language plpgsql
as
$$
BEGIN
    insert into movie_screening_seats(free, movie_screening_id, seat_id)
    SELECT true, ms.id, s.id
    FROM movie_screenings ms
    CROSS JOIN seats s
    WHERE ms.cinema_room_id = s.cinema_room_id
    and ms.id = new.id;

    return new;
end;
$$;

alter function create_movie_screening_seats() owner to postgres;

