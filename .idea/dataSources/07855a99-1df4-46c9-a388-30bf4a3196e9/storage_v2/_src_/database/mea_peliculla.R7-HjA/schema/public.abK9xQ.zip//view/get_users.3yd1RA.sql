create view get_users(id, first_name, last_name, age, gender, email, password) as
SELECT c.person_id AS id,
       p.first_name,
       p.last_name,
       p.age,
       p.gender,
       c.email,
       c.password
FROM customers c
         JOIN persons p ON c.person_id = p.id;

alter table get_users
    owner to postgres;

