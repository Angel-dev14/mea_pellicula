create function movie_comments(_movie_id bigint)
    returns TABLE(movie_id bigint, title text, comment text, customer text, date date)
    language plpgsql
as
$$
begin
    if _movie_id is null then
        raise exception 'Enter valid movie_id';
    end if;

    return query
        select m.id                                              as movie_id,
               m.title::text,
               c.content::text                                   as comment,
               (p.first_name || ' ' || ' ' || p.last_name)::text as customer,
               c.date::date
        from comments c
                 join customers c2 on c.customer_id = c2.person_id
                 join persons p on c2.person_id = p.id
                 join movies m on c.movie_id = m.id
        where c.movie_id = _movie_id;

end
$$;

alter function movie_comments(bigint) owner to postgres;

