create view customer_payments_num_and_cost(person_id, full_name, number, amount_paid) as
SELECT c.person_id,
       (p2.first_name::text || ' '::text) || p2.last_name::text AS full_name,
       count(*)                                                 AS number,
       sum(p.price_paid)                                        AS amount_paid
FROM payments p
         JOIN customers c ON c.person_id = p.customer_id
         JOIN persons p2 ON c.person_id = p2.id
         JOIN reservations r ON p.reservation_id = r.id
GROUP BY c.person_id, ((p2.first_name::text || ' '::text) || p2.last_name::text);

alter table customer_payments_num_and_cost
    owner to postgres;

