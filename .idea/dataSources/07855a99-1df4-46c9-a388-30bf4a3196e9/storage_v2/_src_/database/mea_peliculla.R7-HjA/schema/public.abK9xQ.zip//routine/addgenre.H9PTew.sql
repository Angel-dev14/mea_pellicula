create procedure addgenre(IN _name character varying, IN _description character varying)
    language plpgsql
as
$$
begin
    insert into genres (name, description)
    values (_name, _description);
end
$$;

alter procedure addgenre(varchar, varchar) owner to postgres;

