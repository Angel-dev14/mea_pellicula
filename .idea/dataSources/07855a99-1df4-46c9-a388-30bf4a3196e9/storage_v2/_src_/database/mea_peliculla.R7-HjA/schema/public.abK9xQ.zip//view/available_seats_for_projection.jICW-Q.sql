create view available_seats_for_projection
            (movie_id, title, start_date, price, cinema_room_id, cinema_room, cinema_id, cinema, city_id, city,
             seat_number, seat_row)
as
SELECT m.id                                     AS movie_id,
       m.title,
       ms.start_date,
       ms.base_price + ms.base_price * s.factor AS price,
       cr.id                                    AS cinema_room_id,
       cr.name                                  AS cinema_room,
       c.id                                     AS cinema_id,
       c.name                                   AS cinema,
       c2.id                                    AS city_id,
       c.name                                   AS city,
       s.seat_number,
       s.row_number                             AS seat_row
FROM movie_screenings ms
         JOIN movies m ON ms.movie_id = m.id
         JOIN cinema_rooms cr ON ms.cinema_room_id = cr.id
         JOIN cinemas c ON cr.cinema_id = c.id
         JOIN cities c2 ON c.city_id = c2.id
         JOIN movie_screening_seats mss ON ms.id = mss.movie_screening_id
         JOIN seats s ON mss.seat_id = s.id
WHERE mss.free IS TRUE;

alter table available_seats_for_projection
    owner to postgres;

