create procedure add_employee(IN first_name character varying, IN last_name character varying, IN age integer, IN gender character, IN email character varying, IN password character varying)
    language plpgsql
as
$$
begin
    if first_name is null or first_name = '' then
        raise exception 'Enter first name!';
    end if;

    if last_name is null or last_name = '' then
        raise exception 'Enter last name!';
    end if;

    if age is null or age < 18 or age > 65 then
        raise exception 'Enter valid age!';
    end if;

    if gender is null or gender not in ('M', 'F', 'O', 'm', 'f', 'o') then
        raise exception 'Enter valid sex!';
    end if;

    if email is null or email = '' then
        raise exception 'Enter email!';
    end if;

    if password is null or password = '' then
        raise exception 'Enter password!';
    end if;

    insert into persons(first_name, last_name, age, gender)
    values (first_name, last_name, age, upper(gender));

    insert into employees(person_id, email, password, empoyed_from)
    values ((select max(id) from persons), email, password, now());
    commit;
end
$$;

alter procedure add_employee(varchar, varchar, integer, char, varchar, varchar) owner to postgres;

