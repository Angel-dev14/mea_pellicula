create view actor_starting_movies(actor_id, actor_name, title) as
SELECT p.id                                                   AS actor_id,
       (p.first_name::text || ' '::text) || p.last_name::text AS actor_name,
       m.title
FROM movies m
         JOIN actor_movies am ON m.id = am.movie_id
         JOIN actors a ON am.actor_id = a.person_id
         JOIN persons p ON a.person_id = p.id;

alter table actor_starting_movies
    owner to postgres;

