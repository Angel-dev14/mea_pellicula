create procedure update_finished_movies()
    language plpgsql
as
$$
declare
    t_row  movie_screenings%rowtype;
    t_rowS movie_screening_seats%rowtype;
begin
    for t_row in select *
                 from movie_screenings
                 where start_date <= (now() + interval '1 day')
                   and start_date > (now() - interval '1 day')
        loop
            if t_row.start_date <= now() - interval '3hours' then
                update movie_screenings set is_finished = true where id = t_row.id;
                for t_rowS in select * from movie_screening_seats where movie_screening_id = t_row.id
                    loop
                        update movie_screening_seats set free = false where id = t_rowS.id;
                    end loop;
            end if;
        end loop;
end
$$;

alter procedure update_finished_movies() owner to postgres;

