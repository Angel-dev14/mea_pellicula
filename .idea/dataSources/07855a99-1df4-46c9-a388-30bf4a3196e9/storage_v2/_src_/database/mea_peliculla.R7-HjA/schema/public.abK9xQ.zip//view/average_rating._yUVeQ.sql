create view average_rating(movie_id, title, average_rating, number_of_ratings) as
SELECT m.id                    AS movie_id,
       m.title,
       round(avg(r.rating), 2) AS average_rating,
       count(r.id)             AS number_of_ratings
FROM ratings r
         JOIN movies m ON r.movie_id = m.id
GROUP BY m.id, m.title;

alter table average_rating
    owner to postgres;

