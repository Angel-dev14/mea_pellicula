create procedure register_customer(IN first_name character varying, IN last_name character varying, IN age integer, IN gender character, IN email character varying, IN password character varying)
    language plpgsql
as
$$
declare
        person_id bigint;
        new_email text;
begin
    new_email := email;
    if exists(select 1 from customers c where c.email = new_email) then
        raise exception 'Email already exists';
    end if;

    if first_name is null or first_name = '' then
        raise exception 'Enter first name!';
    end if;

    if last_name is null or last_name = '' then
        raise exception 'Enter last name!';
    end if;

    if age is null or age < 18 or age > 65 then
        raise exception 'Enter valid age!';
    end if;

    if gender is null or gender not in ('M', 'F', 'O', 'm', 'f', 'o') then
        raise exception 'Enter valid sex!';
    end if;

    if email is null or email = '' then
        raise exception 'Enter email!';
    end if;

    if password is null or password = '' then
        raise exception 'Enter password!';
    end if;

    insert into persons(first_name, last_name, age, gender)
    values (first_name, last_name, age, upper(gender)) returning id into person_id ;

    raise notice 'person id %', person_id;

    insert into customers(person_id, email, password)
    values (person_id, email, password);
    commit;
end
$$;

alter procedure register_customer(varchar, varchar, integer, char, varchar, varchar) owner to postgres;

