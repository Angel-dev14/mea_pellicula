create function add_seats_for_cinema_room() returns trigger
    language plpgsql
as
$$
begin
    for row_n in 1..8
        loop
            for seat_n in 1..20
                loop
                    insert into seats(row_number, factor, cinema_room_id, seat_number)
                    values (row_n,
                            (case
                                 when seat_n in (5, 6, 7, 14, 15, 16) then 1.2
                                 when seat_n in (8, 9, 10, 11, 12, 13) then 1.4
                                 else 1
                                end),
                            (select max(id) from cinema_rooms),
                            seat_n);
                end loop;
        end loop;

    return NEW;
end
$$;

alter function add_seats_for_cinema_room() owner to postgres;

