create function update_tables_affected_by_canceled_reservation() returns trigger
    language plpgsql
as
$$
declare
    _movie_screening_date      timestamp;
    _movie_screening_seats_ids bigint[];
    _movie_screening_seats_id  bigint;
begin
    select ms.start_date
    from reservations r
             join tickets t on r.id = t.reservation_id
             join movie_screening_seats mss on mss.id = t.movie_screening_seat_id
             join movie_screenings ms on mss.movie_screening_id = ms.id
    where r.id = old.id
    into _movie_screening_date;

    if (_movie_screening_date <= now()) then
        raise exception 'Can not cancel reservation for past movie screening!';
    end if;

    select array_agg(mss.id)
    from reservations r
             join tickets t on r.id = t.reservation_id
             join movie_screening_seats mss on mss.id = t.movie_screening_seat_id
    where r.id = old.id
    into _movie_screening_seats_ids;

    raise notice '_movie_screening_seats_ids: %', _movie_screening_seats_ids;

    delete from tickets t where t.reservation_id = old.id;

    if(_movie_screening_seats_ids is not null) then
        foreach _movie_screening_seats_id in array _movie_screening_seats_ids
        loop
            update movie_screening_seats mss
            set free = true
            where mss.id = _movie_screening_seats_id;
        end loop;
    end if;

    delete from payments p where p.reservation_id = old.id;

    return old;
end
$$;

alter function update_tables_affected_by_canceled_reservation() owner to postgres;

